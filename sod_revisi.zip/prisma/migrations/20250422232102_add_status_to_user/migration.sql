-- AlterTable
ALTER TABLE `soddiagram` ADD COLUMN `updateMonth` VARCHAR(50) NULL;
