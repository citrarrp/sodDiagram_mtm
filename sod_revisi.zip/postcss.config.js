const config = {
  plugins: { "@tailwindcss/postcss": {} },
};

module.exports = config;
