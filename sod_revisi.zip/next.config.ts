import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  basePath: "/sodDiagram",
  assetPrefix: "/sodDiagram/",
  trailingSlash: true,
  images: {
    localPatterns: [
      {
        pathname: "/src/app/assets",
        search: "",
      },
    ],
  },
  experimental: {
    webpackMemoryOptimizations: true,
  },
};

export default nextConfig;
